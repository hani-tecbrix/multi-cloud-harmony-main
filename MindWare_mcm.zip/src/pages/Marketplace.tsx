import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Eye, Cloud, Database } from "lucide-react";
import { toast } from "sonner";

// Get logo from Brandfetch CDN
const logoUrlMap: { [key: string]: string } = {
  "amazon.com": "https://cdn.brandfetch.io/idVoqFQ-78/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761646996625bfumLaCV7mg2sQy1fv",
  "microsoft.com": "https://cdn.brandfetch.io/idgS27aNck/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761647174454bfumLaCV7m80_xKfbK",
  "idsWBrtc_i": "https://cdn.brandfetch.io/idsWBrtc_i/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761647217879bfumLaCV7ma21emRFS",
  "google.com": "https://cdn.brandfetch.io/idqwPsNkb7/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761647109683bfumLaCV7mjq0eST-9",
  "oracle.com": "https://cdn.brandfetch.io/idnq7H7qT0/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761652029170bfumLaCV7mUvfv6-ce",
  "ibm.com": "https://cdn.brandfetch.io/ide-CcLw8x/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761652001727bfumLaCV7mzEhVgYCl",
  "salesforce.com": "https://img.logo.dev/salesforce.com?token=public-7fpkVsYqkbYHwUU9gZ5vK",
  "slack.com": "https://img.logo.dev/slack.com?token=public-7fpkVsYqkbYHwUU9gZ5vK",
  "zoom.us": "https://cdn.brandfetch.io/id3aO4Szj3/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761651597948bfumLaCV7mjixOxN6m",
  "atlassian.com": "https://cdn.brandfetch.io/idlQIwGMOK/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761651686529bfumLaCV7mcxZ8N2lX",
  "adobe.com": "https://cdn.brandfetch.io/idkrQGARPW/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761651829573bfumLaCV7mgOrlgZHy",
  "github.com": "https://cdn.brandfetch.io/idZAyF9rlg/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761651878703bfumLaCV7mU56CxsUJ",
  "datadoghq.com": "https://cdn.brandfetch.io/idg33VVWFZ/w/128/h/128/fallback/lettermark/icon.webp?c=1ax1761651921010bfumLaCV7mcDkLNN6A",
  "snowflake.com": "https://img.logo.dev/snowflake.com?token=public-7fpkVsYqkbYHwUU9gZ5vK",
};

const getLogoUrl = (domain: string) => {
  return logoUrlMap[domain] || `https://logo.clearbit.com/${domain}`;
};

const cloudProviders = [
  { 
    id: 1,
    name: "Amazon AWS", 
    type: "Consumption", 
    category: "Cloud Infrastructure", 
    domain: "amazon.com",
    description: "Scalable cloud computing platform"
  },
  { 
    id: 2,
    name: "Microsoft Azure", 
    type: "Consumption", 
    category: "Cloud Infrastructure", 
    domain: "microsoft.com",
    description: "Enterprise cloud services"
  },
  { 
    id: 3,
    name: "Google Cloud", 
    type: "Consumption", 
    category: "Cloud Infrastructure", 
    domain: "google.com",
    description: "AI-powered cloud solutions"
  },
  { 
    id: 4,
    name: "Oracle Cloud", 
    type: "Consumption", 
    category: "Cloud Infrastructure", 
    domain: "oracle.com",
    description: "Enterprise cloud platform"
  },
  { 
    id: 5,
    name: "IBM Cloud", 
    type: "Consumption", 
    category: "Cloud Infrastructure", 
    domain: "ibm.com",
    description: "Hybrid cloud solutions"
  },
];

const saasProviders = [
  { 
    id: 1,
    name: "Salesforce", 
    type: "License", 
    category: "CRM", 
    domain: "salesforce.com",
    description: "Customer relationship management platform"
  },
  { 
    id: 2,
    name: "Microsoft 365", 
    type: "License", 
    category: "Productivity", 
    domain: "idsWBrtc_i",
    description: "Office productivity suite"
  },
  { 
    id: 3,
    name: "Slack", 
    type: "License", 
    category: "Communication", 
    domain: "slack.com",
    description: "Team collaboration platform"
  },
  { 
    id: 4,
    name: "Zoom", 
    type: "Consumption", 
    category: "Communication", 
    domain: "zoom.us",
    description: "Video conferencing solution"
  },
  { 
    id: 5,
    name: "Atlassian", 
    type: "License", 
    category: "Project Management", 
    domain: "atlassian.com",
    description: "Project management tools"
  },
  { 
    id: 6,
    name: "Adobe Creative Cloud", 
    type: "License", 
    category: "Design", 
    domain: "adobe.com",
    description: "Creative design software"
  },
  { 
    id: 7,
    name: "GitHub", 
    type: "License", 
    category: "Development", 
    domain: "github.com",
    description: "Code repository hosting"
  },
  { 
    id: 8,
    name: "Datadog", 
    type: "Consumption", 
    category: "Monitoring", 
    domain: "datadoghq.com",
    description: "Infrastructure monitoring"
  },
  { 
    id: 9,
    name: "Snowflake", 
    type: "Consumption", 
    category: "Data Platform", 
    domain: "snowflake.com",
    description: "Cloud data warehouse"
  },
];

const Marketplace = () => {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  const handleAddProvider = (name: string) => {
    toast.success(`${name} added to your subscriptions!`);
  };

  const handleViewDetails = (provider: typeof cloudProviders[0] | typeof saasProviders[0]) => {
    toast.info(`Viewing details for ${provider.name}`);
    // Add modal or navigation here
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Marketplace</h1>
          <p className="text-sm text-muted-foreground mt-1">Browse and manage cloud providers and SaaS subscriptions</p>
        </div>
      </div>

      {/* Cloud Providers Section */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <div>
            <CardTitle className="text-base font-medium">Cloud Providers</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">Infrastructure and platform services</p>
          </div>
          <Badge variant="secondary">{cloudProviders.length} Providers</Badge>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {cloudProviders.map((provider) => (
              <Card 
                key={provider.id} 
                className="hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden group relative"
                onMouseEnter={() => setHoveredCard(provider.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <CardContent className="p-5">
                  {/* Type Badge - Top Right */}
                  <div className="absolute top-3 right-3">
                    <Badge variant="gray" className="text-xs">
                      {provider.type}
                    </Badge>
                  </div>

                  <div className="flex flex-col space-y-3 min-h-[200px]">
                    {/* Logo - Always Visible */}
                    <div className="flex justify-center">
                      <div className="w-16 h-16 flex items-center justify-center">
                        <img 
                          src={getLogoUrl(provider.domain)} 
                          alt={provider.name}
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                            const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                            if (fallback) fallback.style.display = 'flex';
                          }}
                        />
                        <div className="hidden w-full h-full items-center justify-center">
                          <Cloud className="h-10 w-10 text-primary" />
                        </div>
                      </div>
                    </div>

                    {/* Provider Name */}
                    <h3 className="font-semibold text-sm text-center">{provider.name}</h3>

                    {/* Description - Default State */}
                    <div className={`flex-1 transition-opacity duration-300 ${
                      hoveredCard === provider.id ? 'opacity-0 absolute' : 'opacity-100'
                    }`}>
                      <p className="text-xs text-muted-foreground text-center line-clamp-3">
                        {provider.description}
                      </p>
                    </div>

                    {/* Category - Hover State */}
                    <div className={`transition-opacity duration-300 ${
                      hoveredCard === provider.id ? 'opacity-100' : 'opacity-0 absolute'
                    }`}>
                      <p className="text-xs text-muted-foreground text-center mb-3">
                        {provider.category}
                      </p>
                    </div>

                    {/* View Details Button - Bottom Right (Hover) */}
                    <div className={`mt-auto transition-opacity duration-300 ${
                      hoveredCard === provider.id ? 'opacity-100' : 'opacity-0 absolute'
                    }`}>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="w-full"
                        onClick={() => handleViewDetails(provider)}
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        View Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* SaaS Providers Section */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <div>
            <CardTitle className="text-base font-medium">SaaS Applications</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">Software as a service subscriptions</p>
          </div>
          <Badge variant="secondary">{saasProviders.length} Applications</Badge>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {saasProviders.map((provider) => (
              <Card 
                key={provider.id} 
                className="hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden group relative"
                onMouseEnter={() => setHoveredCard(provider.id + 100)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <CardContent className="p-5">
                  {/* Type Badge - Top Right */}
                  <div className="absolute top-3 right-3">
                    <Badge variant="gray" className="text-xs">
                      {provider.type}
                    </Badge>
                  </div>

                  <div className="flex flex-col space-y-3 min-h-[200px]">
                    {/* Logo - Always Visible */}
                    <div className="flex justify-center">
                      <div className="w-16 h-16 flex items-center justify-center">
                        <img 
                          src={getLogoUrl(provider.domain)} 
                          alt={provider.name}
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                            const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                            if (fallback) fallback.style.display = 'flex';
                          }}
                        />
                        <div className="hidden w-full h-full items-center justify-center">
                          <Database className="h-10 w-10 text-primary" />
                        </div>
                      </div>
                    </div>

                    {/* Provider Name */}
                    <h3 className="font-semibold text-sm text-center">{provider.name}</h3>

                    {/* Description - Default State */}
                    <div className={`flex-1 transition-opacity duration-300 ${
                      hoveredCard === provider.id + 100 ? 'opacity-0 absolute' : 'opacity-100'
                    }`}>
                      <p className="text-xs text-muted-foreground text-center line-clamp-3">
                        {provider.description}
                      </p>
                    </div>

                    {/* Category - Hover State */}
                    <div className={`transition-opacity duration-300 ${
                      hoveredCard === provider.id + 100 ? 'opacity-100' : 'opacity-0 absolute'
                    }`}>
                      <p className="text-xs text-muted-foreground text-center mb-3">
                        {provider.category}
                      </p>
                    </div>

                    {/* View Details Button - Bottom Right (Hover) */}
                    <div className={`mt-auto transition-opacity duration-300 ${
                      hoveredCard === provider.id + 100 ? 'opacity-100' : 'opacity-0 absolute'
                    }`}>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="w-full"
                        onClick={() => handleViewDetails(provider)}
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        View Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Marketplace;
