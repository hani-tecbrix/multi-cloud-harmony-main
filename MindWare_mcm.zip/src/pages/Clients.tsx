import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Building2, ArrowLeft } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const clientsData = [
  { 
    id: 1, 
    name: "Acme Corporation", 
    industry: "Technology", 
    subscriptions: 12, 
    monthlySpend: 45280, 
    status: "active",
    subscriptionDetails: [
      { provider: "AWS", service: "EC2", type: "Consumption", cost: 15000 },
      { provider: "Azure", service: "SQL Database", type: "License", cost: 8500 },
      { provider: "GCP", service: "Cloud Storage", type: "Consumption", cost: 6200 },
      { provider: "Salesforce", service: "Enterprise", type: "License", cost: 15580 },
    ]
  },
  { 
    id: 2, 
    name: "TechStart Inc", 
    industry: "Startup", 
    subscriptions: 8, 
    monthlySpend: 28500, 
    status: "active",
    subscriptionDetails: [
      { provider: "AWS", service: "Lambda", type: "Consumption", cost: 8500 },
      { provider: "Slack", service: "Business+", type: "License", cost: 12000 },
      { provider: "GitHub", service: "Enterprise", type: "License", cost: 8000 },
    ]
  },
  { 
    id: 3, 
    name: "DataFlow Ltd", 
    industry: "Finance", 
    subscriptions: 15, 
    monthlySpend: 62100, 
    status: "active",
    subscriptionDetails: [
      { provider: "AWS", service: "RDS", type: "Consumption", cost: 22000 },
      { provider: "Azure", service: "Active Directory", type: "License", cost: 18500 },
      { provider: "Snowflake", service: "Enterprise", type: "Consumption", cost: 21600 },
    ]
  },
  { 
    id: 4, 
    name: "CloudNet Solutions", 
    industry: "Healthcare", 
    subscriptions: 10, 
    monthlySpend: 38900, 
    status: "active",
    subscriptionDetails: [
      { provider: "GCP", service: "Compute Engine", type: "Consumption", cost: 16400 },
      { provider: "Microsoft 365", service: "E5", type: "License", cost: 14500 },
      { provider: "Zoom", service: "Enterprise", type: "License", cost: 8000 },
    ]
  },
  { 
    id: 5, 
    name: "Digital Dynamics", 
    industry: "Retail", 
    subscriptions: 6, 
    monthlySpend: 19800, 
    status: "active",
    subscriptionDetails: [
      { provider: "AWS", service: "S3", type: "Consumption", cost: 7800 },
      { provider: "Shopify", service: "Plus", type: "License", cost: 12000 },
    ]
  },
];

const Clients = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClient, setSelectedClient] = useState<typeof clientsData[0] | null>(null);

  const filteredClients = clientsData.filter(client =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.industry.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (selectedClient) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setSelectedClient(null)}
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
        </div>

        <div>
          <h1 className="text-2xl font-semibold">{selectedClient.name}</h1>
          <p className="text-sm text-muted-foreground mt-1">{selectedClient.industry}</p>
        </div>

        <div className="grid gap-3 md:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Total Subscriptions</p>
              <p className="text-2xl font-semibold">{selectedClient.subscriptions}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Monthly Spend</p>
              <p className="text-2xl font-semibold">${selectedClient.monthlySpend.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Status</p>
              <Badge variant="secondary" className="bg-success/10 text-success hover:bg-success/20">
                {selectedClient.status}
              </Badge>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">Subscription Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Provider</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Monthly Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedClient.subscriptionDetails.map((sub, idx) => (
                  <TableRow key={idx}>
                    <TableCell className="font-medium text-sm">{sub.provider}</TableCell>
                    <TableCell className="text-sm">{sub.service}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">
                        {sub.type}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right text-sm font-medium">
                      ${sub.cost.toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Client Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your clients and their subscriptions</p>
        </div>
        <Button size="sm" variant="black">
          <Plus className="h-4 w-4 mr-1" />
          Add Client
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search clients by name or industry..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 h-9"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Client</TableHead>
                <TableHead>Industry</TableHead>
                <TableHead className="text-center">Subscriptions</TableHead>
                <TableHead className="text-right">Monthly Spend</TableHead>
                <TableHead className="text-right">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredClients.map((client) => (
                <TableRow 
                  key={client.id} 
                  className="cursor-pointer"
                  onClick={() => setSelectedClient(client)}
                >
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded bg-muted">
                        <Building2 className="h-4 w-4" />
                      </div>
                      <span className="font-medium text-sm">{client.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{client.industry}</TableCell>
                  <TableCell className="text-center text-sm font-medium">{client.subscriptions}</TableCell>
                  <TableCell className="text-right text-sm font-medium">
                    ${(client.monthlySpend / 1000).toFixed(1)}K
                  </TableCell>
                  <TableCell className="text-right">
                    <Badge variant="secondary" className="bg-success/10 text-success hover:bg-success/20">
                      {client.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Clients;
